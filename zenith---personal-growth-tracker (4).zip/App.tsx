
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  LayoutDashboard, 
  Calendar as CalendarIcon, 
  BookHeart, 
  ChevronLeft, 
  ChevronRight, 
  BarChart3,
  Settings,
  Lock,
  Unlock,
  Flame,
  Award,
  Sun,
  Moon,
  Leaf,
  Quote,
  Target as TargetIcon
} from 'lucide-react';
// Using named imports from 'date-fns' to ensure compatibility with modern build tools
import {
  format,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameDay,
  subDays
} from 'date-fns';

import { CategoryType, PlanType, Target, DiaryEntry, AppState, AppTheme } from './types';
import { loadState, saveState } from './services/storageService';
import { Calendar } from './components/Calendar';
import { PlanView } from './components/PlanView';
import { DiarySection } from './components/DiarySection';
import { DailySchedule } from './components/DailySchedule';
import { BADGES, QUOTES } from './constants';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(() => {
    const loaded = loadState();
    return {
      ...loaded,
      theme: loaded.theme || 'light',
      badges: loaded.badges || []
    };
  });
  
  const [activeTab, setActiveTab] = useState<'tracker' | 'diary' | 'stats'>('tracker');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [isLocked, setIsLocked] = useState(!!state.diaryPassword);
  const [passwordInput, setPasswordInput] = useState('');

  useEffect(() => {
    saveState(state);
    // Badge Logic
    const earned = [...state.badges];
    if (state.targets.length > 0 && !earned.includes('first_step')) earned.push('first_step');
    if (earned.length !== state.badges.length) setState(prev => ({ ...prev, badges: earned }));
  }, [state]);

  const addTarget = (title: string, category: CategoryType, planType: PlanType, startTime?: string) => {
    const newTarget: Target = {
      id: crypto.randomUUID(),
      title,
      category,
      planType,
      completed: false,
      date: format(selectedDate, 'yyyy-MM-dd'),
      subTasks: [],
      startTime
    };
    setState(prev => ({ ...prev, targets: [...prev.targets, newTarget] }));
  };

  const updateTargetTime = (targetId: string, newTime: string) => {
    setState(prev => ({
      ...prev,
      targets: prev.targets.map(t => t.id === targetId ? { ...t, startTime: newTime } : t)
    }));
  };

  const toggleTarget = (id: string) => {
    setState(prev => ({
      ...prev,
      targets: prev.targets.map(t => t.id === id ? { ...t, completed: !t.completed } : t)
    }));
  };

  const deleteTarget = (id: string) => {
    setState(prev => ({ ...prev, targets: prev.targets.filter(t => t.id !== id) }));
  };

  const addSubTask = (targetId: string, title: string) => {
    setState(prev => ({
      ...prev,
      targets: prev.targets.map(t => t.id === targetId ? {
        ...t,
        subTasks: [...t.subTasks, { id: crypto.randomUUID(), title, completed: false }]
      } : t)
    }));
  };

  const toggleSubTask = (targetId: string, subTaskId: string) => {
    setState(prev => ({
      ...prev,
      targets: prev.targets.map(t => t.id === targetId ? {
        ...t,
        subTasks: t.subTasks.map(s => s.id === subTaskId ? { ...s, completed: !s.completed } : s)
      } : t)
    }));
  };

  const deleteSubTask = (targetId: string, subTaskId: string) => {
    setState(prev => ({
      ...prev,
      targets: prev.targets.map(t => t.id === targetId ? {
        ...t,
        subTasks: t.subTasks.filter(s => s.id !== subTaskId)
      } : t)
    }));
  };

  const streak = useMemo(() => {
    let count = 0;
    let checkDate = new Date();
    while (true) {
      const dateStr = format(checkDate, 'yyyy-MM-dd');
      const hasCompleted = state.targets.some(t => t.date === dateStr && (t.completed || t.subTasks.some(s => s.completed)));
      if (hasCompleted) { count++; checkDate = subDays(checkDate, 1); } else break;
    }
    return count;
  }, [state.targets]);

  const stats = useMemo(() => {
    return Object.values(CategoryType).map(cat => {
      const catTargets = state.targets.filter(t => t.category === cat);
      const total = catTargets.reduce((acc, t) => acc + (t.subTasks.length || 1), 0);
      const done = catTargets.reduce((acc, t) => acc + (t.subTasks.filter(s => s.completed).length || (t.completed ? 1 : 0)), 0);
      return { label: cat, percentage: total > 0 ? (done / total) * 100 : 0 };
    });
  }, [state.targets]);

  const currentTheme = state.theme === 'dark' ? 'bg-[#0f1115] text-white' : state.theme === 'zen' ? 'bg-[#f8f6f2] text-stone-900' : 'bg-[#fcfdfe] text-slate-900';

  return (
    <div className={`min-h-screen flex flex-col lg:flex-row ${currentTheme} transition-colors duration-700 font-sans`}>
      {/* Sleek Navigation Bar */}
      <nav className={`lg:w-72 border-r border-slate-100 flex flex-col items-center py-10 px-6 z-40 sticky top-0 h-screen ${state.theme === 'dark' ? 'bg-[#16191f] border-slate-800' : 'bg-white'}`}>
        <div className="w-full mb-14 flex items-center space-x-4 px-2">
          <div className="w-12 h-12 bg-slate-900 rounded-[20px] flex items-center justify-center shadow-xl shadow-slate-200">
            <LayoutDashboard className="text-white w-6 h-6" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-black tracking-tight leading-none">ZENITH</span>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Growth OS</span>
          </div>
        </div>

        <div className="flex-1 w-full space-y-2">
          <NavLink active={activeTab === 'tracker'} onClick={() => setActiveTab('tracker')} icon={<CalendarIcon className="w-5 h-5" />} label="Tracker" />
          <NavLink active={activeTab === 'diary'} onClick={() => setActiveTab('diary')} icon={<BookHeart className="w-5 h-5" />} label="Reflections" />
          <NavLink active={activeTab === 'stats'} onClick={() => setActiveTab('stats')} icon={<BarChart3 className="w-5 h-5" />} label="Insights" />
        </div>

        <div className="w-full mt-auto pt-10 border-t border-slate-50 space-y-6">
          <div className="flex justify-between items-center px-2">
             <div className="flex space-x-2">
               <button onClick={() => setState(p => ({...p, theme: 'light'}))} className={`p-2 rounded-xl transition-all ${state.theme === 'light' ? 'bg-slate-100' : 'text-slate-300'}`}><Sun className="w-4 h-4" /></button>
               <button onClick={() => setState(p => ({...p, theme: 'dark'}))} className={`p-2 rounded-xl transition-all ${state.theme === 'dark' ? 'bg-slate-800' : 'text-slate-300'}`}><Moon className="w-4 h-4" /></button>
               <button onClick={() => setState(p => ({...p, theme: 'zen'}))} className={`p-2 rounded-xl transition-all ${state.theme === 'zen' ? 'bg-stone-100' : 'text-slate-300'}`}><Leaf className="w-4 h-4" /></button>
             </div>
             <button onClick={() => { const pw = prompt('Set Security:'); if (pw) setState(p => ({...p, diaryPassword: pw})); }} className="p-2 text-slate-300 hover:text-slate-900 transition-colors"><Settings className="w-5 h-5" /></button>
          </div>
          <div className="bg-slate-50 rounded-3xl p-5 border border-slate-100 flex items-center space-x-4">
             <div className="w-10 h-10 bg-orange-100 rounded-2xl flex items-center justify-center"><Flame className="w-5 h-5 text-orange-500" /></div>
             <div>
               <div className="text-xl font-black text-slate-900">{streak}</div>
               <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Day Streak</div>
             </div>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 p-8 lg:p-14 overflow-y-auto">
        <header className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <div>
            <div className="flex items-center space-x-4 mb-2">
              <button onClick={() => setSelectedDate(subMonths(selectedDate, 1))} className="text-slate-300 hover:text-slate-900"><ChevronLeft className="w-6 h-6" /></button>
              <h2 className="text-4xl font-black tracking-tighter">{format(selectedDate, 'MMMM yyyy')}</h2>
              <button onClick={() => setSelectedDate(addMonths(selectedDate, 1))} className="text-slate-300 hover:text-slate-900"><ChevronRight className="w-6 h-6" /></button>
            </div>
            <p className="text-slate-400 font-bold uppercase tracking-[0.2em] text-xs">{format(selectedDate, 'EEEE, do MMMM')}</p>
          </div>
          
          <div className="flex -space-x-3">
            {BADGES.map((b, i) => (
              <div key={b.id} className={`w-12 h-12 rounded-full border-4 border-white flex items-center justify-center shadow-lg transition-all ${state.badges.includes(b.id) ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-300'}`} title={
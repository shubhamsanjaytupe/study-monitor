
import React from 'react';
// Using named imports from 'date-fns' to ensure compatibility with modern environments
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameDay,
  startOfWeek,
  endOfWeek,
  isToday
} from 'date-fns';
import { Target } from '../types';

interface CalendarProps {
  selectedDate: Date;
  onSelectDate: (date: Date) => void;
  targets: Target[];
}

export const Calendar: React.FC<CalendarProps> = ({ selectedDate, onSelectDate, targets }) => {
  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);

  const days = eachDayOfInterval({
    start: calendarStart,
    end: calendarEnd,
  });

  const getDayStatus = (day: Date) => {
    const dayTargets = targets.filter(t => isSameDay(new Date(t.date), day));
    if (dayTargets.length === 0) return 'none';
    const allCompleted = dayTargets.every(t => t.completed);
    return allCompleted ? 'completed' : 'pending';
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-6">
      <div className="grid grid-cols-7 mb-4">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-xs font-bold text-slate-400 uppercase tracking-wider">
            {day}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {days.map((day, idx) => {
          const status = getDayStatus(day);
          const isCurrentMonth = day.getMonth() === selectedDate.getMonth();
          const isSelected = isSameDay(day, selectedDate);
          
          return (
            <button
              key={idx}
              onClick={() => onSelectDate(day)}
              className={`
                aspect-square flex flex-col items-center justify-center rounded-2xl relative transition-all
                ${!isCurrentMonth ? 'text-slate-300' : 'text-slate-700'}
                ${isSelected ? 'bg-blue-600 text-white shadow-lg scale-105 z-10' : 'hover:bg-slate-50'}
                ${isToday(day) && !isSelected ? 'border-2 border-blue-500' : ''}
              `}
            >
              <span className="text-sm font-semibold">{format(day, 'd')}</span>
              {status !== 'none' && (
                <div className={`
                  w-1.5 h-1.5 rounded-full mt-1
                  ${status === 'completed' ? 'bg-emerald-500' : 'bg-amber-400'}
                  ${isSelected ? 'bg-white' : ''}
                `}></div>
              )}
            </button>
          );
        })}
      </div>
      <div className="mt-6 flex space-x-4 text-xs">
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
          <span className="text-slate-500">Fully Completed</span>
        </div>
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 rounded-full bg-amber-400"></div>
          <span className="text-slate-500">In Progress</span>
        </div>
      </div>
    </div>
  );
};

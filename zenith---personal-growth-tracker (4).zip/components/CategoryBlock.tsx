
import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { CategoryType, PlanType, Target } from '../types';
import { CATEGORY_CONFIG } from '../constants';
import { TargetItem } from './TargetItem';

interface CategoryBlockProps {
  category: CategoryType;
  targets: Target[];
  onAdd: (title: string, category: CategoryType) => void;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onAddSubTask: (targetId: string, title: string) => void;
  onToggleSubTask: (targetId: string, subTaskId: string) => void;
  onDeleteSubTask: (targetId: string, subTaskId: string) => void;
}

export const CategoryBlock: React.FC<CategoryBlockProps> = ({ 
  category, targets, onAdd, onToggle, onDelete, onAddSubTask, onToggleSubTask, onDeleteSubTask 
}) => {
  const [newTitle, setNewTitle] = useState('');
  const config = CATEGORY_CONFIG[category];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTitle.trim()) {
      onAdd(newTitle.trim(), category);
      setNewTitle('');
    }
  };

  const calculateTotalProgress = () => {
    if (targets.length === 0) return 0;
    let totalSteps = 0;
    let completedSteps = 0;
    
    targets.forEach(t => {
      if (t.subTasks.length > 0) {
        totalSteps += t.subTasks.length;
        completedSteps += t.subTasks.filter(s => s.completed).length;
      } else {
        totalSteps += 1;
        if (t.completed) completedSteps += 1;
      }
    });
    
    return (completedSteps / totalSteps) * 100;
  };

  return (
    <div className={`p-5 rounded-2xl ${config.bg} border border-slate-100`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <span className={config.color}>{config.icon}</span>
          <h3 className={`font-bold text-slate-800`}>{category}</h3>
        </div>
        <span className="text-[10px] font-bold bg-white px-2 py-1 rounded-full text-slate-400 shadow-sm">
          {targets.length} TOTAL
        </span>
      </div>

      <div className="space-y-1 mb-4 max-h-[400px] overflow-y-auto pr-1">
        {targets.map(target => (
          <TargetItem 
            key={target.id} 
            target={target} 
            onToggle={onToggle} 
            onDelete={onDelete} 
            onAddSubTask={onAddSubTask}
            onToggleSubTask={onToggleSubTask}
            onDeleteSubTask={onDeleteSubTask}
          />
        ))}
        {targets.length === 0 && (
          <p className="text-xs text-slate-400 italic text-center py-4">Set your first {category} target.</p>
        )}
      </div>

      <form onSubmit={handleSubmit} className="relative">
        <input 
          type="text"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          placeholder={`Add ${category}...`}
          className="w-full pl-3 pr-10 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 bg-white"
        />
        <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-blue-500">
          <Plus className="w-5 h-5" />
        </button>
      </form>
      
      <div className="mt-4 pt-3 border-t border-slate-200/50">
        <div className="w-full bg-slate-200/50 rounded-full h-1.5">
          <div 
            className={`h-1.5 rounded-full transition-all duration-700 ${config.color.replace('text', 'bg')}`} 
            style={{ width: `${calculateTotalProgress()}%` }}
          />
        </div>
      </div>
    </div>
  );
};

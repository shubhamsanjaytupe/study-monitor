
import React, { useState } from 'react';
import { Clock, Plus, GripVertical } from 'lucide-react';
import { Target, CategoryType, PlanType } from '../types';
import { TargetItem } from './TargetItem';

interface DailyScheduleProps {
  targets: Target[];
  onAddTarget: (title: string, category: CategoryType, planType: PlanType, startTime?: string) => void;
  onToggleTarget: (id: string) => void;
  onDeleteTarget: (id: string) => void;
  onAddSubTask: (targetId: string, title: string) => void;
  onToggleSubTask: (targetId: string, subTaskId: string) => void;
  onDeleteSubTask: (targetId: string, subTaskId: string) => void;
  onUpdateTargetTime: (targetId: string, newTime: string) => void;
}

const HOURS = Array.from({ length: 15 }, (_, i) => {
  const hour = i + 7; // 7 AM to 9 PM
  return `${hour.toString().padStart(2, '0')}:00`;
});

export const DailySchedule: React.FC<DailyScheduleProps> = ({ 
  targets, onAddTarget, onToggleTarget, onDeleteTarget, 
  onAddSubTask, onToggleSubTask, onDeleteSubTask, onUpdateTargetTime
}) => {
  const [isAddingAt, setIsAddingAt] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState('');

  const handleDrop = (e: React.DragEvent, time: string) => {
    e.preventDefault();
    const targetId = e.dataTransfer.getData('targetId');
    if (targetId) {
      onUpdateTargetTime(targetId, time);
    }
  };

  const handleDragStart = (e: React.DragEvent, targetId: string) => {
    e.dataTransfer.setData('targetId', targetId);
  };

  return (
    <div className="bg-white rounded-[32px] border border-slate-100 shadow-sm p-8 overflow-hidden">
      <div className="flex items-center justify-between mb-10">
        <div>
          <h3 className="text-xl font-bold text-slate-900">Today's Schedule</h3>
          <p className="text-sm text-slate-400 font-medium">Drag tasks to organize your day</p>
        </div>
        <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
          <Clock className="w-6 h-6" />
        </div>
      </div>

      <div className="space-y-6 relative">
        {/* Timeline Line */}
        <div className="absolute left-10 top-2 bottom-0 w-px bg-slate-100 z-0" />

        {HOURS.map((hour) => {
          const hourTargets = targets.filter(t => t.startTime === hour);
          
          return (
            <div 
              key={hour} 
              className="flex items-start group min-h-[40px] relative z-10"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => handleDrop(e, hour)}
            >
              <div className="w-20 pr-4 text-[10px] font-black text-slate-300 uppercase mt-1">
                {hour}
              </div>
              
              <div className="flex-1 space-y-2">
                {hourTargets.map(target => (
                  <TargetItem 
                    key={target.id}
                    target={target}
                    onToggle={onToggleTarget}
                    onDelete={onDeleteTarget}
                    onAddSubTask={onAddSubTask}
                    onToggleSubTask={onToggleSubTask}
                    onDeleteSubTask={onDeleteSubTask}
                    draggable
                    onDragStart={(e) => handleDragStart(e, target.id)}
                  />
                ))}

                {isAddingAt === hour ? (
                  <form 
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (newTitle.trim()) {
                        onAddTarget(newTitle, CategoryType.SELF_DEVELOPMENT, PlanType.DAILY, hour);
                        setNewTitle('');
                        setIsAddingAt(null);
                      }
                    }}
                    className="flex space-x-2 animate-in slide-in-from-top-2 duration-300"
                  >
                    <input 
                      autoFocus
                      type="text" 
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      placeholder="What needs to be done?"
                      className="flex-1 bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500/10"
                    />
                    <button type="submit" className="px-4 bg-slate-900 text-white rounded-2xl text-xs font-bold">Add</button>
                    <button onClick={() => setIsAddingAt(null)} className="px-4 text-slate-400 font-bold text-xs">Cancel</button>
                  </form>
                ) : (
                  <button 
                    onClick={() => setIsAddingAt(hour)}
                    className="flex items-center text-[10px] font-black text-slate-300 uppercase tracking-widest opacity-0 group-hover:opacity-100 hover:text-blue-500 transition-all p-2"
                  >
                    <Plus className="w-3 h-3 mr-2" /> Add Task
                  </button>
                )}
              </div>
            </div>
          );
        })}

        {/* Unscheduled Tasks */}
        {targets.filter(t => !t.startTime).length > 0 && (
          <div className="mt-12 pt-8 border-t border-slate-50">
             <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Unscheduled</h4>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {targets.filter(t => !t.startTime).map(target => (
                   <TargetItem 
                    key={target.id}
                    target={target}
                    onToggle={onToggleTarget}
                    onDelete={onDeleteTarget}
                    onAddSubTask={onAddSubTask}
                    onToggleSubTask={onToggleSubTask}
                    onDeleteSubTask={onDeleteSubTask}
                    draggable
                    onDragStart={(e) => handleDragStart(e, target.id)}
                  />
                ))}
             </div>
          </div>
        )}
      </div>
    </div>
  );
};


import React, { useState, useEffect, useRef } from 'react';
import { format } from 'date-fns';
import { Save, Image as ImageIcon, Sparkles, Hash, BarChart3, Download, Loader2, X } from 'lucide-react';
import { DiaryEntry } from '../types';
import { MOODS as MOOD_LIST } from '../constants';
import { GoogleGenAI } from "@google/genai";

interface DiarySectionProps {
  entry?: DiaryEntry;
  onSave: (entry: DiaryEntry) => void;
  date: Date;
}

export const DiarySection: React.FC<DiarySectionProps> = ({ entry, onSave, date }) => {
  const [content, setContent] = useState(entry?.content || '');
  const [mood, setMood] = useState(entry?.mood || '😊');
  const [tags, setTags] = useState<string[]>(entry?.tags || []);
  const [media, setMedia] = useState<string[]>(entry?.media || []);
  const [tagInput, setTagInput] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setContent(entry?.content || '');
    setMood(entry?.mood || '😊');
    setTags(entry?.tags || []);
    setMedia(entry?.media || []);
  }, [entry, date]);

  useEffect(() => {
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = setTimeout(() => handleSave(), 2000);
    return () => { if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current); };
  }, [content, mood, tags, media]);

  const handleSave = () => {
    setIsSaving(true);
    const newEntry: DiaryEntry = {
      ...entry,
      date: format(date, 'yyyy-MM-dd'),
      content,
      mood,
      tags,
      media,
      lastModified: Date.now()
    };
    onSave(newEntry);
    setTimeout(() => setIsSaving(false), 500);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setMedia(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeMedia = (index: number) => {
    setMedia(prev => prev.filter((_, i) => i !== index));
  };

  const runAIAnalysis = async () => {
    if (!content.trim()) return;
    setIsAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze this diary entry for sentiment and key themes. Return a JSON object with "sentiment" (one word) and "keywords" (array of 3 keywords). Entry: "${content}"`,
        config: { responseMimeType: "application/json" }
      });
      const data = JSON.parse(response.text || '{}');
      const updatedEntry = {
        ...entry,
        date: format(date, 'yyyy-MM-dd'),
        content, mood, tags, media,
        aiInsights: data,
        lastModified: Date.now()
      } as DiaryEntry;
      onSave(updatedEntry);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
      <div className="p-6 border-b border-slate-50 bg-slate-50/30 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">{format(date, 'MMMM d, yyyy')}</h2>
          <p className="text-sm text-slate-400">Personal reflections & memories</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex bg-white border border-slate-200 rounded-xl p-1 shadow-sm">
            {MOOD_LIST.map(m => (
              <button
                key={m}
                onClick={() => setMood(m)}
                className={`w-8 h-8 flex items-center justify-center rounded-lg transition-all ${mood === m ? 'bg-blue-100 scale-110' : 'hover:bg-slate-50'}`}
              >
                {m}
              </button>
            ))}
          </div>
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-slate-400 hover:text-blue-600 transition-colors"
            title="Attach Image"
          >
            <ImageIcon className="w-5 h-5" />
          </button>
          <input type="file" ref={fileInputRef} className="hidden" onChange={handleImageUpload} accept="image/*" />
          <button 
            onClick={runAIAnalysis}
            disabled={isAnalyzing}
            className="p-2 text-purple-400 hover:text-purple-600 transition-colors"
            title="AI Analysis"
          >
            {isAnalyzing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
          </button>
        </div>
      </div>

      <div className="flex-1 relative flex flex-col p-6 overflow-y-auto">
        {entry?.aiInsights && (
          <div className="mb-4 p-3 bg-purple-50 border border-purple-100 rounded-xl flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Sparkles className="w-4 h-4 text-purple-500" />
              <span className="text-xs font-bold text-purple-700 uppercase tracking-tight">AI Insights: {entry.aiInsights.sentiment}</span>
            </div>
            <div className="flex space-x-1">
              {entry.aiInsights.keywords.map(kw => (
                <span key={kw} className="text-[10px] bg-purple-100 text-purple-600 px-2 py-0.5 rounded-full font-bold">#{kw}</span>
              ))}
            </div>
          </div>
        )}

        {media.length > 0 && (
          <div className="flex gap-4 overflow-x-auto pb-4 mb-4 scrollbar-hide">
            {media.map((src, i) => (
              <div key={i} className="relative shrink-0 w-32 h-32 rounded-2xl overflow-hidden group border border-slate-100">
                <img src={src} className="w-full h-full object-cover" />
                <button 
                  onClick={() => removeMedia(i)}
                  className="absolute top-1 right-1 p-1 bg-black/50 text-white rounded-full opacity-0 group-hover:opacity-100"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="mb-4 flex flex-wrap gap-2">
          {tags.map(tag => (
            <span key={tag} className="inline-flex items-center px-2 py-1 bg-blue-50 text-blue-600 text-[10px] font-black rounded-lg border border-blue-100">
              #{tag.toUpperCase()}
              <button onClick={() => setTags(tags.filter(t => t !== tag))} className="ml-1">×</button>
            </span>
          ))}
          <input
            type="text"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && tagInput.trim()) {
                setTags([...tags, tagInput.trim()]);
                setTagInput('');
              }
            }}
            placeholder="Add tag..."
            className="text-[10px] bg-transparent border-none focus:outline-none w-24 text-slate-400 font-bold uppercase"
          />
        </div>

        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Start writing your story..."
          className="flex-1 w-full text-lg text-slate-700 placeholder-slate-200 bg-transparent border-none focus:ring-0 resize-none leading-relaxed min-h-[300px]"
        />
      </div>

      <div className="p-4 border-t border-slate-50 flex justify-between items-center text-[10px] text-slate-400 font-bold uppercase tracking-widest">
        <span>Words: {content.trim() ? content.trim().split(/\s+/).length : 0}</span>
        <div className="flex items-center">
          {isSaving ? <Save className="w-3 h-3 mr-1 animate-pulse text-emerald-500" /> : <Save className="w-3 h-3 mr-1" />}
          {isSaving ? "Saving..." : `Last Sync: ${format(new Date(entry?.lastModified || Date.now()), 'HH:mm')}`}
        </div>
      </div>
    </div>
  );
};

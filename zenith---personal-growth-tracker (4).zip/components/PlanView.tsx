
import React from 'react';
import { CategoryType, PlanType, Target } from '../types';
import { CategoryBlock } from './CategoryBlock';

interface PlanViewProps {
  planType: PlanType;
  targets: Target[];
  onAddTarget: (title: string, category: CategoryType, planType: PlanType) => void;
  onToggleTarget: (id: string) => void;
  onDeleteTarget: (id: string) => void;
  onAddSubTask: (targetId: string, title: string) => void;
  onToggleSubTask: (targetId: string, subTaskId: string) => void;
  onDeleteSubTask: (targetId: string, subTaskId: string) => void;
}

export const PlanView: React.FC<PlanViewProps> = ({ 
  planType, targets, onAddTarget, onToggleTarget, onDeleteTarget,
  onAddSubTask, onToggleSubTask, onDeleteSubTask
}) => {
  const categories = Object.values(CategoryType);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {categories.map(cat => (
        <CategoryBlock
          key={cat}
          category={cat}
          targets={targets.filter(t => t.category === cat)}
          onAdd={(title, category) => onAddTarget(title, category, planType)}
          onToggle={onToggleTarget}
          onDelete={onDeleteTarget}
          onAddSubTask={onAddSubTask}
          onToggleSubTask={onToggleSubTask}
          onDeleteSubTask={onDeleteSubTask}
        />
      ))}
    </div>
  );
};

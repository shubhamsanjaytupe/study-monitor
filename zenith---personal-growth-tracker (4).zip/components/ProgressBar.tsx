
import React from 'react';

interface ProgressBarProps {
  progress: number;
  label: string;
  colorClass?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ progress, label, colorClass = 'bg-blue-600' }) => {
  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs font-medium text-slate-600">{label}</span>
        <span className="text-xs font-semibold text-slate-700">{Math.round(progress)}%</span>
      </div>
      <div className="w-full bg-slate-200 rounded-full h-2">
        <div 
          className={`h-2 rounded-full transition-all duration-500 ${colorClass}`} 
          style={{ width: `${progress}%` }}
        ></div>
      </div>
    </div>
  );
};


import React, { useState } from 'react';
import { CheckCircle2, Circle, Trash2, ChevronDown, ChevronUp, Plus, X, GRP, Clock } from 'lucide-react';
import { Target, SubTask } from '../types';

interface TargetItemProps {
  target: Target;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onAddSubTask: (targetId: string, title: string) => void;
  onToggleSubTask: (targetId: string, subTaskId: string) => void;
  onDeleteSubTask: (targetId: string, subTaskId: string) => void;
  draggable?: boolean;
  onDragStart?: (e: React.DragEvent) => void;
}

export const TargetItem: React.FC<TargetItemProps> = ({ 
  target, onToggle, onDelete, onAddSubTask, onToggleSubTask, onDeleteSubTask, draggable, onDragStart 
}) => {
  const [expanded, setExpanded] = useState(false);
  const [subTaskTitle, setSubTaskTitle] = useState('');

  const handleAddSubTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (subTaskTitle.trim()) {
      onAddSubTask(target.id, subTaskTitle.trim());
      setSubTaskTitle('');
    }
  };

  const completedSubTasks = target.subTasks.length > 0 
    ? target.subTasks.filter(s => s.completed).length 
    : (target.completed ? 1 : 0);
  
  const totalSubTasks = target.subTasks.length > 0 ? target.subTasks.length : 1;
  const progressPercent = (completedSubTasks / totalSubTasks) * 100;

  return (
    <div 
      className={`group bg-white border border-slate-200/60 rounded-2xl transition-all duration-300 ${draggable ? 'cursor-grab active:cursor-grabbing' : ''} hover:border-slate-300 hover:shadow-sm mb-2`}
      draggable={draggable}
      onDragStart={onDragStart}
    >
      <div className="flex items-center p-4">
        <div 
          className="flex items-center space-x-4 flex-1 cursor-pointer" 
          onClick={() => onToggle(target.id)}
        >
          {target.completed ? (
            <div className="w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center">
              <CheckCircle2 className="w-3.5 h-3.5 text-white" />
            </div>
          ) : (
            <div className="w-5 h-5 border-2 border-slate-200 rounded-full" />
          )}
          
          <div className="flex flex-col min-w-0">
            <span className={`text-sm font-semibold truncate ${target.completed ? 'text-slate-400 line-through font-normal' : 'text-slate-800'}`}>
              {target.title}
            </span>
            <div className="flex items-center space-x-2 mt-0.5">
              {target.startTime && (
                <span className="flex items-center text-[10px] font-bold text-blue-500 uppercase">
                  <Clock className="w-3 h-3 mr-1" /> {target.startTime}
                </span>
              )}
              {target.subTasks.length > 0 && (
                <span className="text-[10px] text-slate-400 font-bold uppercase">
                  {completedSubTasks}/{target.subTasks.length} steps
                </span>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button 
            onClick={() => setExpanded(!expanded)}
            className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-400"
          >
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          <button 
            onClick={() => onDelete(target.id)}
            className="p-1.5 hover:bg-red-50 rounded-lg text-slate-300 hover:text-red-500"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {expanded && (
        <div className="px-4 pb-4 pt-1 border-t border-slate-50">
          <div className="space-y-1 mb-3">
            {target.subTasks.map(sub => (
              <div key={sub.id} className="flex items-center justify-between py-1.5 group/sub">
                <div 
                  className="flex items-center space-x-3 cursor-pointer flex-1"
                  onClick={() => onToggleSubTask(target.id, sub.id)}
                >
                  <div className={`w-3.5 h-3.5 rounded-full border ${sub.completed ? 'bg-emerald-400 border-emerald-400' : 'border-slate-200'}`} />
                  <span className={`text-xs ${sub.completed ? 'text-slate-400 line-through' : 'text-slate-600 font-medium'}`}>
                    {sub.title}
                  </span>
                </div>
                <button 
                  onClick={() => onDeleteSubTask(target.id, sub.id)}
                  className="opacity-0 group-hover/sub:opacity-100 text-slate-300 hover:text-red-400"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
          
          <form onSubmit={handleAddSubTask} className="flex items-center space-x-2">
            <input 
              type="text"
              value={subTaskTitle}
              onChange={(e) => setSubTaskTitle(e.target.value)}
              placeholder="Add step..."
              className="flex-1 bg-slate-50 border border-slate-100 rounded-xl px-3 py-1.5 text-xs focus:ring-1 focus:ring-blue-500/20"
            />
            <button type="submit" className="p-1.5 bg-slate-900 text-white rounded-xl hover:bg-black transition-colors">
              <Plus className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

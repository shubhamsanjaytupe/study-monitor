
import React from 'react';
import { Activity, BookOpen, Heart, Wallet, Trophy, Target as TargetIcon, Zap, Shield } from 'lucide-react';
import { CategoryType } from './types';

export const CATEGORY_CONFIG: Record<CategoryType, { color: string; icon: React.ReactNode; bg: string; darkBg: string }> = {
  [CategoryType.PHYSICAL]: { 
    color: 'text-emerald-600', 
    bg: 'bg-emerald-50',
    darkBg: 'bg-emerald-900/20',
    icon: <Activity className="w-5 h-5" /> 
  },
  [CategoryType.EDUCATIONAL]: { 
    color: 'text-blue-600', 
    bg: 'bg-blue-50',
    darkBg: 'bg-blue-900/20',
    icon: <BookOpen className="w-5 h-5" /> 
  },
  [CategoryType.SELF_DEVELOPMENT]: { 
    color: 'text-purple-600', 
    bg: 'bg-purple-50',
    darkBg: 'bg-purple-900/20',
    icon: <Heart className="w-5 h-5" /> 
  },
  [CategoryType.MONEY]: { 
    color: 'text-amber-600', 
    bg: 'bg-amber-50',
    darkBg: 'bg-amber-900/20',
    icon: <Wallet className="w-5 h-5" /> 
  },
};

export const BADGES = [
  { id: 'first_step', name: 'First Step', icon: <TargetIcon className="w-4 h-4" />, desc: 'Complete your first target' },
  { id: 'consistency', name: 'Consistent', icon: <Zap className="w-4 h-4" />, desc: 'Maintain a 3-day streak' },
  { id: 'zen_master', name: 'Zen Master', icon: <Shield className="w-4 h-4" />, desc: 'Write 5 diary entries' },
  { id: 'achiever', name: 'Overachiever', icon: <Trophy className="w-4 h-4" />, desc: 'Complete 50 targets total' },
];

export const QUOTES = [
  "The only person you are destined to become is the person you decide to be.",
  "Success is not final, failure is not fatal: it is the courage to continue that counts.",
  "Small daily improvements over time lead to stunning results.",
  "Believe you can and you're halfway there.",
  "Your future is created by what you do today, not tomorrow."
];

export const MOODS = ['😊', '😐', '😔', '🚀', '😴', '🧠', '💼'];


import { AppState } from '../types';

const STORAGE_KEY = 'zenith_tracker_data';

export const saveState = (state: AppState) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
};

export const loadState = (): AppState => {
  const data = localStorage.getItem(STORAGE_KEY);
  // Default state to ensure all required AppState properties are present
  const defaultState: AppState = { 
    targets: [], 
    diaryEntries: {}, 
    theme: 'light', 
    badges: [] 
  };
  
  if (!data) return defaultState;
  
  try {
    const parsed = JSON.parse(data);
    return {
      ...defaultState,
      ...parsed
    };
  } catch (e) {
    // Return default state on parse error
    return defaultState;
  }
};

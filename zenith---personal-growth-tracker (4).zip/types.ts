
export enum CategoryType {
  PHYSICAL = 'Physical',
  EDUCATIONAL = 'Educational',
  SELF_DEVELOPMENT = 'Self-Development',
  MONEY = 'Money'
}

export enum PlanType {
  DAILY = 'Daily',
  WEEKLY = 'Weekly',
  MONTHLY = 'Monthly'
}

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Target {
  id: string;
  title: string;
  category: CategoryType;
  planType: PlanType;
  completed: boolean;
  date: string; // YYYY-MM-DD
  subTasks: SubTask[];
  startTime?: string; // HH:mm format
}

export interface DiaryEntry {
  date: string; // YYYY-MM-DD
  content: string;
  mood: string; // Emoji
  tags: string[];
  media?: string[]; // Base64 images
  aiInsights?: {
    sentiment: string;
    keywords: string[];
  };
  lastModified: number;
}

export type AppTheme = 'light' | 'dark' | 'zen';

export interface AppState {
  targets: Target[];
  diaryEntries: Record<string, DiaryEntry>;
  diaryPassword?: string;
  theme: AppTheme;
  badges: string[];
}
